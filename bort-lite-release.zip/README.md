# Bort Lite

This pre-built apk gives a preview of the Bort SDK, without requiring a full
AOSP integration/build. Install on any device with `adb` access.

See [Documentation](https://mflt.io/bort-lite) for more details, including
limitations compared the full Bort SDK.
