# Bort Lite: Android Quickstart APK

This pre-built apk gives a preview of the Android SDK, without requiring a full
AOSP integration/build. Install on any device with `adb` access.

See [Documentation](https://mflt.io/bort-lite) for more details, including
limitations compared the full Android SDK as well as links to the source code.
