#!/bin/bash

# Installs a bort apk on a vanilla aosp image (i.e. with no memfault services/sepolicy/certs..),
# grants all privileged permissions to bort, and disable sepolicy enforcement if possible (to allow getprop device serial).

# See README.md for more information.

if [[ -z $1 ]]; then
  echo "Usage:"
  echo "install-bort-lite.sh <project-key>"
  echo ""
  echo "or, with root, to disable sepolicy enforcement:"
  echo "install-bort-lite.sh <project-key> root"
  exit 0
fi

# -g grants privileged permissions
adb install -r -g bort-lite.apk

# Allow bort to read serial sysprop without espolicy changes (only available when rooted)
if [[ -n $2 ]]; then
  adb root
  adb shell setenforce 0
fi

# Allow bort to run in background (replaces <allow-in-power-save package="$BORT_APPLICATION_ID" /> in com.memfault.bort.xml.in)
adb shell dumpsys deviceidle whitelist +com.memfault.bort.lite

# Set project key from arg
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.UPDATE_PROJECT_KEY -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver --es com.memfault.intent.extra.PROJECT_KEY "$1"

# Enable Bort
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.BORT_ENABLE -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver --ez com.memfault.intent.extra.BORT_ENABLED true

# Enable Dev Mode
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.DEV_MODE --ez com.memfault.intent.extra.DEV_MODE_ENABLED true -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver

# Collect Metrics immediately
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.REQUEST_METRICS_COLLECTION -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver
