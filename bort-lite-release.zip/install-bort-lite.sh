#!/bin/bash

# Installs a bort apk on a vanilla aosp image (i.e. with no memfault services/sepolicy/certs..),
# grants all privileged permissions to bort, and disable sepolicy enforcement if possible (to allow getprop device serial).

# See README.md for more information.

while getopts ":k:s:r" opt; do
  case $opt in
    k) project_key="$OPTARG" ;;
    s) device_serial="$OPTARG" ;;
    r) enable_root=1 ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ -z $project_key ]]; then
  echo "Usage:"
  echo "install-bort-lite.sh -k <project-key> [-s <device-serial>] [-r]"
  echo ""
  echo "-s to override the device serial is optional"
  echo "-r to used root to disable sepolicy enforcement is optional"
  exit 0
fi

# -g grants privileged permissions
adb install -r -g bort-lite.apk

# Allow bort to read serial sysprop without espolicy changes (only available when rooted)
if [[ -n $enable_root ]]; then
  echo "Disabling sepolicy enforcement.."
  adb root
  adb shell setenforce 0
fi

# Allow bort to run in background (replaces <allow-in-power-save package="$BORT_APPLICATION_ID" /> in com.memfault.bort.xml.in)
adb shell dumpsys deviceidle whitelist +com.memfault.bort.lite

# Set project key from arg
echo "Setting project key to $project_key.."
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.UPDATE_PROJECT_KEY -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver --es com.memfault.intent.extra.PROJECT_KEY "$project_key"

if [[ -n $device_serial ]]; then
  echo "Overriding serial to $device_serial.."
  # Set device serial
  adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.OVERRIDE_SERIAL -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver --es com.memfault.intent.extra.SERIAL "$device_serial"
fi

# Enable Bort
echo "Enabling Bort.."
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.BORT_ENABLE -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver --ez com.memfault.intent.extra.BORT_ENABLED true

# Enable Dev Mode
echo "Enabling Dev Mode."
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.DEV_MODE --ez com.memfault.intent.extra.DEV_MODE_ENABLED true -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver

# Collect Metrics immediately
echo "Collecting metrics.."
adb shell am broadcast --receiver-include-background -a com.memfault.intent.action.REQUEST_METRICS_COLLECTION -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver

echo "Finished installing Bort Lite!"
