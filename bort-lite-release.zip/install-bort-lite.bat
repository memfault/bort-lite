@echo off

REM Installs a bort apk on a vanilla aosp image, grants privileged permissions, and disables sepolicy enforcement if possible.

REM Check for required project key argument
if "%~1"=="" (
    echo Usage:
    echo install-bort-lite.bat ^<project-key^>
    echo.
    echo To disable sepolicy enforcement ^(requires root^):
    echo install-bort-lite.bat ^<project-key^> root
    exit /B 0
)

REM Install bort-lite.apk with privileged permissions
adb install -r -g bort-lite.apk

REM Disable sepolicy enforcement if the second argument is "root"
if "%~2"=="root" (
    adb root
    adb shell setenforce 0
)

REM Allow bort to run in background
adb shell dumpsys deviceidle whitelist +com.memfault.bort.lite

REM --receiver-include-background is only available on API 26+
set "receiver_bg="
for /f "tokens=1" %%i in ('adb shell getprop ro.build.version.sdk') do set "sdk_version=%%i"
if defined sdk_version if %sdk_version% GTR 25 set "receiver_bg=--receiver-include-background"

REM Set project key from argument
adb shell am broadcast ^
    %receiver_bg% ^
    -a com.memfault.intent.action.UPDATE_PROJECT_KEY ^
    -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver ^
    --es com.memfault.intent.extra.PROJECT_KEY "%~1"

REM Enable Bort
adb shell am broadcast ^
    %receiver_bg% ^
    -a com.memfault.intent.action.BORT_ENABLE ^
    -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver ^
    --ez com.memfault.intent.extra.BORT_ENABLED true

REM Enable Dev Mode
adb shell am broadcast ^
    %receiver_bg% ^
    -a com.memfault.intent.action.DEV_MODE ^
    --ez com.memfault.intent.extra.DEV_MODE_ENABLED true ^
    -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver

REM Collect Metrics immediately
adb shell am broadcast ^
    %receiver_bg% ^
    -a com.memfault.intent.action.REQUEST_METRICS_COLLECTION ^
    -n com.memfault.bort.lite/com.memfault.bort.receivers.ShellControlReceiver
